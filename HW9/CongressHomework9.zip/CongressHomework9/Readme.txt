
In Developing this App I followed various tutorial and took help from online forums such as stackoverflow.com
Few of the major tutorial are mentioned below.


https://www.simplifiedcoding.net/android-navigation-drawer-example-using-fragments/

http://androidopentutorials.com/android-listview-with-alphabetical-side-index/

http://www.vogella.com/tutorials/AndroidListView/article.html


http://www.vogella.com/tutorials/android.html

http://www.limbaniandroid.com/2013/01/sorting-arraylist-string-arraylist-and.html

And took help from plenty of questions form stack overflow and Android official documentation.

Third party Libraries used:
GSON
Picasso
JSON