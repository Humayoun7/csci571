package com.humayoun.congresshomework9;

/**
 * Created by user on 14/11/2016.
 */

public class Committee {
    public String chamber;
    public String committee_id;
    public String name;
    public String parent_committee_id;
    public boolean subcommittee;
    public String contact="N.A";
    public String office="N.A";




}
