package com.humayoun.congresshomework9;

/**
 * Created by user on 20/11/2016.
 */

public class Bill {

    public String billID="N.A";
    public String billType="N.A";
    public String sponsor="N.A";
    public String chamber="N.A";

    public String introducedon="N.A";
    public String status="N.A";
    public String congressUrl="N.A";
    public String versionStatus="N.A";
    public String billUrl="N.A";


    public String billtitle="N.A";

}
