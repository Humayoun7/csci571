package com.humayoun.congresshomework9;

/**
 * Created by user on 14/11/2016.
 */

public class Legislators {

    public String first_name;
    public  String las_name;
    public String party;
    public String state;
    public int district;
    public String bioID;
    public String imgURL;
    public String email="N.A";
    public String  chamber;
    public  String office="N.A";
    public String  fax ="N.A";
    public String  birthday="N.A";
    public int  term;
    public  String startTerm="N.A";
    public String  endTerm="N.A";
    public String facebook;
    public String twitter;
    public String website;
    public String contact="N.A";
    public String title;






}
